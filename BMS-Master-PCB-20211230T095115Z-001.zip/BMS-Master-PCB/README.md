# BMS Master PCB
Ingress-Protected Battery Pack with an Integrated Battery Management System

Project Group 5: reVolt. Sponsored by Green Waterways Ltd. and supervised by Dr. Patrick Palmer.


Contain schematic and PCB design for the Master board of the pack's BMS.

# Members:

Selikem Kwadzovia	301303898

Cao Thanh Nhat Tan	301269797

Armaan Singh Lageri	301319129

Sepehr Rezvani	301291960

Shri Sai Teja Duddella	301383852

